<?php
define('BD_HOST','localhost');
define('BD_DATABASE','juegoglobo');
define('BD_USER','root');
define('DB_PASSWORD','root');